<?php
/**
 * Plugin Name:       OpenAI Content Generator
 * Plugin URI:        https://yourwebsite.com/
 * Description:       Generates content using OpenAI for WordPress posts and pages.
 * Version:           1.0.0
 * Author:            Your Name
 * Author URI:        https://yourwebsite.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       openai-content-generator
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Display an admin notice when the plugin is activated
function ocg_admin_notice() {
    echo '<div class="notice notice-success is-dismissible">
             <p>OpenAI Content Generator plugin is active!</p>
         </div>';
}
add_action( 'admin_notices', 'ocg_admin_notice' );

// Register the admin menu under Tools
function ocg_register_admin_menu() {
    add_management_page(
        'OpenAI Content Generator',
        'OpenAI Generator',
        'manage_options',
        'openai-content-generator',
        'ocg_render_admin_page'
    );
}
add_action( 'admin_menu', 'ocg_register_admin_menu' );

// Render the main plugin interface
function ocg_render_admin_page() {
    ?>
    <div class="wrap">
        <h1>OpenAI Content Generator</h1>
        <?php ocg_render_form(); ?>
        <?php ocg_handle_submission(); ?>
    </div>
    <?php
}

// Render the prompt input form
function ocg_render_form() {
    ?>
    <form method="post">
        <label for="ocg_use_case"><strong>Choose a use case:</strong></label><br>
        <select name="ocg_use_case" id="ocg_use_case" style="max-width: 500px; width: 100%;">
            <option value="blog_title">✍️ Blog Title</option>
            <option value="product_description">📦 Product Description</option>
            <option value="seo_meta">🌐 SEO Meta Description</option>
            <option value="social_post">📢 Social Media Post</option>
        </select><br><br>

        <label for="ocg_prompt"><strong>Enter your topic or idea:</strong></label><br>
        <input type="text" id="ocg_prompt" name="ocg_prompt" style="width: 100%; max-width: 500px;"><br><br>

        <input type="submit" name="ocg_generate" class="button button-primary" value="Generate with OpenAI">
    </form>
    <?php
}

// Handle form submission and call OpenAI API
function ocg_handle_submission() {
    // Handle the "Save as Draft" form submission
    if ( isset($_POST['ocg_save_draft']) && !empty($_POST['ocg_draft_content']) ) {
        $content = sanitize_text_field($_POST['ocg_draft_content']);
        $title = 'AI Draft - ' . ucfirst(str_replace('_', ' ', sanitize_text_field($_POST['ocg_use_case'])));

        $new_post = [
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => 'draft',
            'post_author'  => get_current_user_id(),
            'post_type'    => 'post',
        ];

        $post_id = wp_insert_post($new_post);

        if ( $post_id && !is_wp_error($post_id) ) {
            echo '<div style="background: #d4edda; padding: 10px; border-left: 4px solid #155724;">
                    ✅ Draft saved successfully! <a href="' . esc_url(get_edit_post_link($post_id)) . '" target="_blank">View draft</a>.
                  </div>';
        } else {
            echo '<div style="background: #ffecec; color: #d8000c; padding: 10px;">
                    ❌ Failed to save draft.
                  </div>';
        }
    }

    if ( isset($_POST['ocg_generate']) && !empty($_POST['ocg_prompt']) ) {
        $user_input = sanitize_text_field($_POST['ocg_prompt']);
        $use_case = sanitize_text_field($_POST['ocg_use_case']);

        switch ($use_case) {
            case 'blog_title':
                $prompt = "Write a blog post title about: {$user_input}";
                break;
            case 'product_description':
                $prompt = "Write a short product description for: {$user_input}";
                break;
            case 'seo_meta':
                $prompt = "Create an SEO meta description for: {$user_input}";
                break;
            case 'social_post':
                $prompt = "Write a social media caption about: {$user_input}";
                break;
            default:
                $prompt = $user_input; // fallback to raw input
        }

        $api_key = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : '';

        echo '<h2>Result:</h2>';

        if ( empty($api_key) ) {
            echo '<div style="background: #ffecec; color: #d8000c; padding: 10px;">
                    ⚠️ Error: OpenAI API key is missing. Please add it to wp-config.php.
                  </div>';
            return;
        }

        echo '<div style="background: #fff8e1; padding: 10px; color: #333;">
                ⏳ Generating response...
              </div>';

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body' => json_encode([
                'model'    => 'gpt-3.5-turbo',
                'messages' => [
                    ['role' => 'user', 'content' => $prompt]
                ],
                'temperature' => 0.7,
            ]),
            'timeout' => 20,
        ]);

        if ( is_wp_error( $response ) ) {
            error_log( 'OpenAI API error: ' . $response->get_error_message() );
            echo '<div style="background: #ffecec; color: #d8000c; padding: 10px;">
                    ❌ Error contacting OpenAI: ' . esc_html( $response->get_error_message() ) . '
                  </div>';
        } else {
            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            $ai_output = $body['choices'][0]['message']['content'] ?? 'No response from OpenAI.';

            echo '<div style="background: #e7f5ff; padding: 10px; border-left: 4px solid #2b8a3e;">
                    <strong>✅ Success:</strong><br>' . esc_html($ai_output) . '
                  </div>';

            echo '<form method="post" style="margin-top: 10px;">
                    <input type="hidden" name="ocg_draft_content" value="' . esc_attr($ai_output) . '">
                    <input type="hidden" name="ocg_use_case" value="' . esc_attr($use_case) . '">
                    <input type="submit" name="ocg_save_draft" class="button button-secondary" value="Save as Draft">
                  </form>';
        }
    }
}